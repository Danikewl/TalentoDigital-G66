el .html reemplaza al innerHTML
tambien tenemos el .text