mkdir -p assets/css assets/img && touch index.html README.md assets/css/style.css
