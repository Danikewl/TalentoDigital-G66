let nombre = document.getElementById("nombre");
let apellido = document.getElementById("apellido");
let profesion = document.getElementById("profesion");
let salario = document.getElementById("salario");


nombre.innerHTML = prompt("Ingrese un nombre");
apellido.innerHTML = prompt("Ingrese un apellido");
profesion.innerHTML = prompt("Ingrese un profesion");
salario.innerHTML = prompt("Ingrese un salario");

nombre.style.color = "red"
apellido.style.color = "yellow"
profesion.style.color = "#031020"