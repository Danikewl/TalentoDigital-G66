let nombre = "Lautaro";
let apellido = "Martin";
let saludoDefinitivo = "Hola " + nombre + " " + apellido;

console.log(saludoDefinitivo);
