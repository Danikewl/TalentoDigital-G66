let resultado =
  document.getElementById("resultado"); /* Guardo la etiqueta en una variable */
let variable1 = prompt("ingresa el primer numero");
let operador = prompt("Ingrese un operador");
let variable2 = prompt("ingresa el segundo numero");

console.log(variable1);
console.log(operador);
console.log(variable2);

if (operador === "*") {
  resultado.innerHTML = Number(variable1) * Number(variable2);
}
if (operador === "-") {
  resultado.innerHTML = Number(variable1) - Number(variable2);
}
if (operador === "+") {
  resultado.innerHTML = Number(variable1) + Number(variable2);
}
if (operador === "/") {
  resultado.innerHTML = Number(variable1) / Number(variable2);
}

// if(operador === "*") { resultado.innerHTML =  Number(variable1) * Number(variable2) }
// else if(operador === "-") { resultado.innerHTML =  Number(variable1) - Number(variable2) }
// else if(operador === "+") { resultado.innerHTML = Number(variable1) + Number(variable2)  }
// else if(operador === "/") { resultado.innerHTML =  Number(variable1) / Number(variable2)  }
// else{resultado.innerHTML = resultado.innerHTML = "No tipeaste un operador adecuado!" }
